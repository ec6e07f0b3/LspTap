package com.cyhtn.autotap;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 6001;
    private static final Pattern PACKAGE_PATTERN = Pattern.compile("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+");

    private SharedPreferences prefs;
    private EditText targetInput;
    private EditText intervalInput;
    private EditText xInput;
    private EditText yInput;
    private CheckBox pauseTouchCheck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(AppConfig.PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.rgb(22, 27, 36));
        getWindow().setNavigationBarColor(Color.rgb(22, 27, 36));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(245, 247, 250));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("LspTap 连点器");
        title.setTextSize(25);
        title.setTextColor(Color.rgb(25, 32, 43));
        title.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        root.addView(title, matchWrap());

        TextView intro = new TextView(this);
        intro.setText("LSPosed 模块 + 悬浮启停。先在 LSPosed 中启用模块，并把目标应用加入作用域。建议先在普通测试应用里验证。\n\n为了尽量不打断手动操作，默认在手指触摸屏幕时暂停连点，松手后等待约 120 ms 再恢复。");
        intro.setTextSize(14);
        intro.setTextColor(Color.rgb(75, 83, 96));
        intro.setPadding(0, dp(10), 0, dp(18));
        root.addView(intro, matchWrap());

        targetInput = addEditField(root, "目标应用包名", "例如：com.example.app", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        intervalInput = addEditField(root, "点击间隔（毫秒，8–2000）", "20", InputType.TYPE_CLASS_NUMBER);
        xInput = addEditField(root, "点击 X 坐标（屏幕内容宽度百分比，0–100）", "50", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        yInput = addEditField(root, "点击 Y 坐标（屏幕内容高度百分比，0–100）", "50", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        pauseTouchCheck = new CheckBox(this);
        pauseTouchCheck.setText("检测到真实触摸时暂停（推荐）");
        pauseTouchCheck.setTextColor(Color.rgb(35, 42, 52));
        pauseTouchCheck.setTextSize(15);
        pauseTouchCheck.setChecked(prefs.getBoolean(AppConfig.KEY_PAUSE_TOUCH, true));
        LinearLayout.LayoutParams checkParams = matchWrap();
        checkParams.topMargin = dp(8);
        checkParams.bottomMargin = dp(12);
        root.addView(pauseTouchCheck, checkParams);

        Button saveButton = button("保存配置");
        root.addView(saveButton, buttonParams());
        saveButton.setOnClickListener(v -> saveConfig());

        Button overlayButton = button("保存并显示悬浮球");
        root.addView(overlayButton, buttonParams());
        overlayButton.setOnClickListener(v -> {
            if (!saveConfig()) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_OVERLAY);
                return;
            }
            startOverlayService();
        });

        Button stopButton = button("关闭悬浮球");
        root.addView(stopButton, buttonParams());
        stopButton.setOnClickListener(v -> {
            prefs.edit().putBoolean(AppConfig.KEY_ENABLED, false).apply();
            stopService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "已停止连点并关闭悬浮球", Toast.LENGTH_SHORT).show();
        });

        TextView footer = new TextView(this);
        footer.setText("速度说明：8 ms 只是设定的最小间隔，不代表设备能稳定达到 125 次/秒。点击派发在目标应用主线程执行，实际速度取决于应用的触摸处理与帧耗时。\n\n注意：LSPosed 作用域要手动勾选目标应用；只填包名不会自动给模块授权。");
        footer.setTextSize(12);
        footer.setTextColor(Color.rgb(95, 102, 114));
        footer.setPadding(0, dp(16), 0, 0);
        root.addView(footer, matchWrap());

        loadSavedValues();
        setContentView(scroll);
    }

    private void loadSavedValues() {
        targetInput.setText(prefs.getString(AppConfig.KEY_TARGET, ""));
        intervalInput.setText(String.valueOf(prefs.getInt(AppConfig.KEY_INTERVAL, AppConfig.DEFAULT_INTERVAL_MS)));
        xInput.setText(String.format(Locale.US, "%.1f", prefs.getFloat(AppConfig.KEY_X, 50f)));
        yInput.setText(String.format(Locale.US, "%.1f", prefs.getFloat(AppConfig.KEY_Y, 50f)));
    }

    private boolean saveConfig() {
        String target = targetInput.getText().toString().trim();
        if (!PACKAGE_PATTERN.matcher(target).matches()) {
            targetInput.setError("请输入完整包名，例如 com.example.app");
            Toast.makeText(this, "目标包名格式不正确", Toast.LENGTH_SHORT).show();
            return false;
        }

        int interval;
        float x;
        float y;
        try {
            interval = Integer.parseInt(intervalInput.getText().toString().trim());
            x = Float.parseFloat(xInput.getText().toString().trim());
            y = Float.parseFloat(yInput.getText().toString().trim());
        } catch (RuntimeException e) {
            Toast.makeText(this, "间隔和坐标必须是数字", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (interval < AppConfig.MIN_INTERVAL_MS || interval > AppConfig.MAX_INTERVAL_MS) {
            intervalInput.setError("范围为 8–2000 ms");
            return false;
        }
        if (x < 0f || x > 100f || y < 0f || y > 100f) {
            Toast.makeText(this, "坐标百分比必须在 0–100 之间", Toast.LENGTH_SHORT).show();
            return false;
        }

        prefs.edit()
                .putString(AppConfig.KEY_TARGET, target)
                .putInt(AppConfig.KEY_INTERVAL, interval)
                .putFloat(AppConfig.KEY_X, x)
                .putFloat(AppConfig.KEY_Y, y)
                .putBoolean(AppConfig.KEY_PAUSE_TOUCH, pauseTouchCheck.isChecked())
                .apply();
        Toast.makeText(this, "配置已保存", Toast.LENGTH_SHORT).show();
        return true;
    }

    private void startOverlayService() {
        Intent service = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(service);
        } else {
            startService(service);
        }
        Toast.makeText(this, "悬浮球已启动；点击悬浮球切换连点状态", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                startOverlayService();
            } else {
                Toast.makeText(this, "未授予悬浮窗权限", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private EditText addEditField(LinearLayout parent, String labelText, String hint, int inputType) {
        TextView label = new TextView(this);
        label.setText(labelText);
        label.setTextSize(14);
        label.setTextColor(Color.rgb(42, 49, 60));
        LinearLayout.LayoutParams labelParams = matchWrap();
        labelParams.topMargin = dp(8);
        parent.addView(label, labelParams);

        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(16);
        input.setInputType(inputType);
        input.setHint(hint);
        input.setPadding(dp(12), dp(8), dp(12), dp(8));
        parent.addView(input, matchWrap());
        return input;
    }

    private Button button(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        return button;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(6);
        return params;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
