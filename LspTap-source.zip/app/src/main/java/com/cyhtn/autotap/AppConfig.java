package com.cyhtn.autotap;

final class AppConfig {
    static final String PREFS = "lsp_tap_config";
    static final String KEY_TARGET = "target_package";
    static final String KEY_INTERVAL = "interval_ms";
    static final String KEY_X = "x_percent";
    static final String KEY_Y = "y_percent";
    static final String KEY_PAUSE_TOUCH = "pause_on_real_touch";
    static final String KEY_ENABLED = "enabled";
    static final String PROVIDER_URI = "content://com.cyhtn.autotap.config";

    static final int MIN_INTERVAL_MS = 8;
    static final int MAX_INTERVAL_MS = 2000;
    static final int DEFAULT_INTERVAL_MS = 20;

    private AppConfig() {}
}
