package com.cyhtn.autotap;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.lang.reflect.Method;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Legacy Xposed entry used by LSPosed.
 * The module dispatches completed DOWN/UP pairs on the target Activity's UI thread.
 * It intentionally pauses while a real gesture is active to reduce touch-stream conflicts.
 */
public class HookEntry implements IXposedHookLoadPackage {
    private static final String MODULE_PACKAGE = "com.cyhtn.autotap";
    private static final Uri CONFIG_URI = Uri.parse(AppConfig.PROVIDER_URI);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ScheduledExecutorService CONFIG_EXECUTOR = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread thread = new Thread(r, "LspTap-config-reader");
        thread.setDaemon(true);
        return thread;
    });
    private static final Set<Method> TOUCH_METHODS = Collections.synchronizedSet(new HashSet<>());

    private static volatile WeakReference<Activity> currentActivity = new WeakReference<>(null);
    private static volatile boolean enabled;
    private static volatile boolean pauseOnTouch = true;
    private static volatile boolean realTouchActive;
    private static volatile long lastRealTouchUptime;
    private static volatile int intervalMs = AppConfig.DEFAULT_INTERVAL_MS;
    private static volatile float xPercent = 50f;
    private static volatile float yPercent = 50f;
    private static volatile String configuredTarget = "";
    private static boolean tickScheduled;
    private static ScheduledFuture<?> configFuture;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (MODULE_PACKAGE.equals(lpparam.packageName)) return;

        try {
            XposedBridge.hookAllMethods(Activity.class, "onResume", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (!(param.thisObject instanceof Activity)) return;
                    Activity activity = (Activity) param.thisObject;
                    currentActivity = new WeakReference<>(activity);
                    realTouchActive = false;
                    lastRealTouchUptime = 0L;
                    installTouchObserver(activity);
                    startConfigPolling(activity);
                }
            });

            XposedBridge.hookAllMethods(Activity.class, "onPause", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (!(param.thisObject instanceof Activity)) return;
                    Activity activity = (Activity) param.thisObject;
                    Activity current = currentActivity.get();
                    if (current == activity) {
                        currentActivity = new WeakReference<>(null);
                        realTouchActive = false;
                        stopConfigPolling();
                        MAIN.post(() -> {
                            MAIN.removeCallbacks(TICK);
                            tickScheduled = false;
                        });
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("LspTap: failed to install lifecycle hooks: " + t);
        }
    }

    private static void installTouchObserver(Activity activity) {
        try {
            Method method = activity.getClass().getMethod("dispatchTouchEvent", MotionEvent.class);
            if (!TOUCH_METHODS.add(method)) return;
            XposedBridge.hookMethod(method, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    if (param.args == null || param.args.length == 0 || !(param.args[0] instanceof MotionEvent)) return;
                    MotionEvent event = (MotionEvent) param.args[0];
                    int action = event.getActionMasked();
                    long now = SystemClock.uptimeMillis();
                    lastRealTouchUptime = now;
                    if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                        realTouchActive = true;
                    } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                        realTouchActive = false;
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("LspTap: unable to observe touch dispatch in " + activity.getClass().getName() + ": " + t);
        }
    }

    private static synchronized void startConfigPolling(Activity activity) {
        stopConfigPollingLocked();
        WeakReference<Activity> activityRef = new WeakReference<>(activity);
        configFuture = CONFIG_EXECUTOR.scheduleWithFixedDelay(() -> {
            Activity owner = activityRef.get();
            if (owner == null || owner.isFinishing()) return;
            readConfig(owner);
            MAIN.post(HookEntry::refreshTicker);
        }, 0, 100, TimeUnit.MILLISECONDS);
    }

    private static synchronized void stopConfigPolling() {
        stopConfigPollingLocked();
        enabled = false;
    }

    private static void stopConfigPollingLocked() {
        if (configFuture != null) {
            configFuture.cancel(false);
            configFuture = null;
        }
    }

    private static void readConfig(Activity activity) {
        try {
            ContentResolver resolver = activity.getContentResolver();
            Bundle data = resolver.call(CONFIG_URI, "getConfig", null, null);
            if (data == null) {
                enabled = false;
                return;
            }
            configuredTarget = data.getString(AppConfig.KEY_TARGET, "");
            boolean authorized = data.getBoolean("authorized", false);
            boolean targetMatches = activity.getPackageName().equals(configuredTarget);
            enabled = authorized && targetMatches && data.getBoolean(AppConfig.KEY_ENABLED, false);
            intervalMs = Math.max(AppConfig.MIN_INTERVAL_MS,
                    Math.min(AppConfig.MAX_INTERVAL_MS, data.getInt(AppConfig.KEY_INTERVAL, AppConfig.DEFAULT_INTERVAL_MS)));
            xPercent = clamp(data.getFloat(AppConfig.KEY_X, 50f), 0f, 100f);
            yPercent = clamp(data.getFloat(AppConfig.KEY_Y, 50f), 0f, 100f);
            pauseOnTouch = data.getBoolean(AppConfig.KEY_PAUSE_TOUCH, true);
        } catch (Throwable t) {
            enabled = false;
            XposedBridge.log("LspTap: config read failed: " + t);
        }
    }

    private static void refreshTicker() {
        Activity activity = currentActivity.get();
        if (enabled && activity != null && !tickScheduled) {
            tickScheduled = true;
            MAIN.post(TICK);
        } else if (!enabled && tickScheduled) {
            MAIN.removeCallbacks(TICK);
            tickScheduled = false;
        }
    }

    private static final Runnable TICK = new Runnable() {
        @Override
        public void run() {
            Activity activity = currentActivity.get();
            if (!enabled || activity == null || activity.isFinishing() || activity.isDestroyed()) {
                tickScheduled = false;
                return;
            }

            if (activity.hasWindowFocus()) {
                long now = SystemClock.uptimeMillis();
                boolean touchBusy = realTouchActive || (now - lastRealTouchUptime < 120L);
                if (!pauseOnTouch || !touchBusy) {
                    dispatchTap(activity);
                }
            }

            if (enabled && currentActivity.get() == activity) {
                tickScheduled = true;
                MAIN.postDelayed(this, intervalMs);
            } else {
                tickScheduled = false;
            }
        }
    };

    private static void dispatchTap(Activity activity) {
        try {
            View decor = activity.getWindow() == null ? null : activity.getWindow().getDecorView();
            if (decor == null || decor.getWidth() <= 0 || decor.getHeight() <= 0 || !decor.isAttachedToWindow()) return;

            float x = decor.getWidth() * xPercent / 100f;
            float y = decor.getHeight() * yPercent / 100f;
            long downTime = SystemClock.uptimeMillis();
            MotionEvent down = MotionEvent.obtain(downTime, downTime,
                    MotionEvent.ACTION_DOWN, x, y, 0);
            down.setSource(InputDevice.SOURCE_TOUCHSCREEN);
            try {
                decor.dispatchTouchEvent(down);
            } finally {
                down.recycle();
            }

            long upTime = Math.max(downTime, SystemClock.uptimeMillis());
            MotionEvent up = MotionEvent.obtain(downTime, upTime,
                    MotionEvent.ACTION_UP, x, y, 0);
            up.setSource(InputDevice.SOURCE_TOUCHSCREEN);
            try {
                decor.dispatchTouchEvent(up);
            } finally {
                up.recycle();
            }
        } catch (Throwable t) {
            XposedBridge.log("LspTap: synthetic tap failed: " + t);
        }
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
