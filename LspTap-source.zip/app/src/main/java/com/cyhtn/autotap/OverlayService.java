package com.cyhtn.autotap;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class OverlayService extends Service {
    private static final String CHANNEL_ID = "lsptap_controls";
    private static final int NOTIFICATION_ID = 8124;

    private WindowManager windowManager;
    private WindowManager.LayoutParams layoutParams;
    private TextView bubble;
    private SharedPreferences prefs;
    private float downRawX;
    private float downRawY;
    private int startX;
    private int startY;
    private boolean dragging;
    private int touchSlop;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(AppConfig.PREFS, MODE_PRIVATE);
        touchSlop = Math.round(8 * getResources().getDisplayMetrics().density);
        createNotificationChannel();
        startAsForeground();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        showBubble();
    }

    private void startAsForeground() {
        Intent openApp = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notification = new Notification.Builder(this, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .setContentTitle("LspTap 连点器")
                    .setContentText("点击悬浮球启停；真实触摸时默认暂停")
                    .setContentIntent(pendingIntent)
                    .setOngoing(true)
                    .build();
        } else {
            notification = new Notification.Builder(this)
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .setContentTitle("LspTap 连点器")
                    .setContentText("点击悬浮球启停")
                    .setContentIntent(pendingIntent)
                    .setOngoing(true)
                    .build();
        }
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "LspTap 浮动控制", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("连点器悬浮控制状态");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void showBubble() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        bubble = new TextView(this);
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(12);
        bubble.setGravity(Gravity.CENTER);
        bubble.setElevation(8 * getResources().getDisplayMetrics().density);
        updateBubbleAppearance();

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        layoutParams = new WindowManager.LayoutParams(dp(54), dp(54), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START;
        layoutParams.x = dp(12);
        layoutParams.y = dp(180);

        bubble.setOnTouchListener(this::handleBubbleTouch);
        try {
            windowManager.addView(bubble, layoutParams);
        } catch (RuntimeException e) {
            stopSelf();
        }
    }

    private boolean handleBubbleTouch(View view, MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                startX = layoutParams.x;
                startY = layoutParams.y;
                dragging = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - downRawX;
                float dy = event.getRawY() - downRawY;
                if (Math.abs(dx) > touchSlop || Math.abs(dy) > touchSlop) dragging = true;
                if (dragging) {
                    layoutParams.x = startX + Math.round(dx);
                    layoutParams.y = startY + Math.round(dy);
                    try {
                        windowManager.updateViewLayout(bubble, layoutParams);
                    } catch (RuntimeException ignored) {
                    }
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (!dragging) toggleEnabled();
                return true;
            case MotionEvent.ACTION_CANCEL:
                return true;
            default:
                return true;
        }
    }

    private void toggleEnabled() {
        boolean enabled = prefs.getBoolean(AppConfig.KEY_ENABLED, false);
        prefs.edit().putBoolean(AppConfig.KEY_ENABLED, !enabled).apply();
        updateBubbleAppearance();
    }

    private void updateBubbleAppearance() {
        if (bubble == null) return;
        boolean enabled = prefs.getBoolean(AppConfig.KEY_ENABLED, false);
        bubble.setText(enabled ? "连\n开" : "连\n停");
        GradientDrawable background = new GradientDrawable();
        background.setShape(GradientDrawable.OVAL);
        background.setColor(enabled ? Color.rgb(33, 150, 83) : Color.rgb(76, 86, 101));
        background.setStroke(dp(1), Color.argb(170, 255, 255, 255));
        bubble.setBackground(background);
        bubble.invalidate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        updateBubbleAppearance();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (bubble != null && windowManager != null) {
            try { windowManager.removeView(bubble); } catch (RuntimeException ignored) {}
        }
        bubble = null;
        stopForeground(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
