package com.cyhtn.autotap;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.Process;

import java.util.Arrays;

public class ConfigProvider extends ContentProvider {
    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        if (!"getConfig".equals(method) || getContext() == null) {
            return new Bundle();
        }

        SharedPreferences prefs = getContext().getSharedPreferences(AppConfig.PREFS, android.content.Context.MODE_PRIVATE);
        String target = prefs.getString(AppConfig.KEY_TARGET, "");
        int callerUid = Binder.getCallingUid();
        boolean allowed = callerUid == Process.myUid();

        if (!allowed && !target.isEmpty()) {
            try {
                String[] callerPackages = getContext().getPackageManager().getPackagesForUid(callerUid);
                allowed = callerPackages != null && Arrays.asList(callerPackages).contains(target);
            } catch (RuntimeException ignored) {
                allowed = false;
            }
        }

        Bundle result = new Bundle();
        result.putBoolean("authorized", allowed);
        if (!allowed) {
            result.putBoolean(AppConfig.KEY_ENABLED, false);
            return result;
        }

        result.putString(AppConfig.KEY_TARGET, target);
        result.putBoolean(AppConfig.KEY_ENABLED, prefs.getBoolean(AppConfig.KEY_ENABLED, false));
        result.putInt(AppConfig.KEY_INTERVAL, prefs.getInt(AppConfig.KEY_INTERVAL, AppConfig.DEFAULT_INTERVAL_MS));
        result.putFloat(AppConfig.KEY_X, prefs.getFloat(AppConfig.KEY_X, 50f));
        result.putFloat(AppConfig.KEY_Y, prefs.getFloat(AppConfig.KEY_Y, 50f));
        result.putBoolean(AppConfig.KEY_PAUSE_TOUCH, prefs.getBoolean(AppConfig.KEY_PAUSE_TOUCH, true));
        return result;
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) { return null; }
    @Override public String getType(Uri uri) { return "vnd.android.cursor.item/vnd.com.cyhtn.autotap.config"; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
}
